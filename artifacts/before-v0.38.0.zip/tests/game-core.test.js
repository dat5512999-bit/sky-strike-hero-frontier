'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const files = [
  'src/namespace.js', 'src/config.js', 'src/utils/math.js',
  'src/skins/SkinRegistry.js', 'src/skins/SkinPacks.js',
  'src/entities/Bullet.js', 'src/entities/EnemyBullet.js', 'src/entities/Player.js', 'src/entities/Enemy.js',
  'src/entities/Boss.js', 'src/entities/PowerUp.js',
  'src/systems/Weapon.js', 'src/systems/Collision.js',
  'src/systems/DifficultySystem.js', 'src/systems/Spawner.js', 'src/systems/GameState.js', 'src/systems/Effects.js', 'src/systems/BattlefieldRenderer.js', 'src/systems/SkillSystem.js', 'src/systems/ChallengeSystem.js', 'src/systems/StageDirector.js', 'src/systems/SupportSystem.js',
  'src/systems/InputController.js'
];

function loadGameCore() {
  const storage = new Map();
  const context = vm.createContext({ console, localStorage: {
    getItem: (key) => storage.has(key) ? storage.get(key) : null,
    setItem: (key, value) => storage.set(key, value)
  } });
  context.globalThis = context;
  files.forEach((file) => vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file }));
  return context.SkyStrike;
}

test('玩家目標位置被限制在遊戲邊界內', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240, 560);
  player.setTarget(-100, 9999);
  assert.equal(player.targetX, 25);
  assert.equal(player.targetY, 688);
});

test('玩家平滑移動，不會瞬間傳送到遠端目標', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240, 560);
  player.setTarget(400, 200);
  player.update(0.1);
  assert.equal(player.x, 312);
  assert.equal(player.y, 488);
});

test('武器依射速自動生成單發子彈', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240, 560);
  const weapon = new ns.systems.Weapon();
  const bullets = [];
  weapon.update(0.01, player, bullets);
  assert.equal(bullets.length, 1);
  assert.equal(bullets[0].x, player.x);
  weapon.update(0.05, player, bullets);
  assert.equal(bullets.length, 1);
});

test('自動射擊會交替使用皮膚包的兩種子彈外觀', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240, 560);
  const weapon = new ns.systems.Weapon();
  const bullets = [];
  weapon.update(0.2, player, bullets);
  weapon.update(0.2, player, bullets);
  assert.deepEqual(Array.from(bullets, (bullet) => bullet.variant), [0, 1]);
  assert.equal(bullets[0].damage, bullets[1].damage);
});

test('內建 6 套皮膚可選擇且無效 ID 不會覆蓋目前選擇', () => {
  const ns = loadGameCore();
  assert.equal(ns.skins.all().length, 6);
  assert.equal(ns.skins.select('fast-food'), true);
  assert.equal(ns.skins.current().name, '歡樂速食');
  assert.equal(ns.skins.select('not-a-skin'), false);
  assert.equal(ns.skins.current().id, 'fast-food');
});

test('兩發子彈可擊破普通敵機且只計分一次', () => {
  const ns = loadGameCore();
  const enemy = new ns.entities.Enemy(100, 100);
  let destroyed = 0;
  const onDestroyed = () => { destroyed += 1; };
  ns.systems.Collision.resolvePlayerBullets([new ns.entities.Bullet(100, 100)], [enemy], onDestroyed);
  assert.equal(enemy.health, 1);
  assert.equal(destroyed, 0);
  ns.systems.Collision.resolvePlayerBullets([new ns.entities.Bullet(100, 100)], [enemy], onDestroyed);
  assert.equal(enemy.active, false);
  assert.equal(destroyed, 1);
});

test('玩家受擊後有短暫無敵，生命為零時死亡', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(100, 100);
  assert.equal(player.takeDamage(1), true);
  assert.equal(player.health, 2);
  assert.equal(player.takeDamage(1), false);
  player.update(2);
  player.takeDamage(2);
  assert.equal(player.health, 0);
  assert.equal(player.active, false);
});

test('生成器會隨遊戲時間逐步縮短生成間隔', () => {
  const ns = loadGameCore();
  const spawner = new ns.systems.Spawner(() => 0.5);
  const initial = spawner.currentInterval();
  spawner.elapsed = ns.config.spawner.rampSeconds;
  assert.ok(spawner.currentInterval() < initial);
  const enemies = [];
  spawner.timer = 0;
  spawner.update(0.016, enemies);
  assert.equal(enemies.length, 1);
  assert.equal(enemies[0].x, ns.config.width / 2);
});

test('威脅等級每 12 秒提升並封頂為 5', () => {
  const ns = loadGameCore();
  const spawner = new ns.systems.Spawner(() => 0.1);
  assert.equal(spawner.threatLevel(), 1);
  spawner.elapsed = 25;
  assert.equal(spawner.threatLevel(), 3);
  spawner.elapsed = 999;
  assert.equal(spawner.threatLevel(), 5);
});

test('射擊敵機會瞄準玩家產生敵方子彈', () => {
  const ns = loadGameCore();
  const enemy = new ns.entities.Enemy(240, 145, { type:'gunner', health:4 });
  enemy.fireCooldown = 0;
  const bullets = [];
  enemy.update(0.016, { player:new ns.entities.Player(240,560), enemyBullets:bullets });
  assert.equal(bullets.length, 1);
  assert.ok(bullets[0].vy > 0);
});

test('草莓與香蕉果實分別啟用散射和高速連射', () => {
  const ns = loadGameCore();
  const skills = new ns.systems.SkillSystem(() => 0);
  const context = { player:new ns.entities.Player(240,560), enemies:[], enemyBullets:[], onDestroyed(){} };
  skills.collect(new ns.entities.PowerUp(0,0,'strawberry'), context);
  skills.collect(new ns.entities.PowerUp(0,0,'banana'), context);
  assert.equal(skills.has('spread'), true);
  assert.equal(skills.has('rapid'), true);
  const weapon = new ns.systems.Weapon();
  const bullets = [];
  weapon.update(0.2, context.player, bullets, skills);
  assert.equal(bullets.length, 3);
  assert.ok(bullets[0].vx < 0 && bullets[2].vx > 0);
});

test('葡萄護盾可抵擋一次傷害且不扣 HP', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240,560);
  player.shieldHits = 1;
  assert.equal(player.takeDamage(1), true);
  assert.equal(player.health, 3);
  assert.equal(player.shieldHits, 0);
});

test('鳳梨果實清除敵方子彈並對畫面敵人造成傷害', () => {
  const ns = loadGameCore();
  const skills = new ns.systems.SkillSystem(() => 0);
  const enemy = new ns.entities.Enemy(100,100,{health:4});
  const enemyBullet = new ns.entities.EnemyBullet(100,100,0,100);
  skills.collect(new ns.entities.PowerUp(0,0,'pineapple'), { player:new ns.entities.Player(240,560), enemies:[enemy], enemyBullets:[enemyBullet], onDestroyed(){} });
  assert.equal(enemyBullet.active, false);
  assert.equal(enemy.health, 1);
});

test('技能系統會在前五秒保證生成第一顆果實', () => {
  const ns = loadGameCore();
  const skills = new ns.systems.SkillSystem(() => 0);
  const powerUps = [];
  skills.update(5.1, powerUps);
  assert.equal(powerUps.length, 1);
  assert.equal(powerUps[0].type, 'strawberry');
});

test('敵方子彈命中玩家後失效並扣除生命', () => {
  const ns = loadGameCore();
  const player = new ns.entities.Player(240,560);
  const bullet = new ns.entities.EnemyBullet(240,560,0,100);
  let hits = 0;
  ns.systems.Collision.resolveEnemyBullets(player,[bullet],() => { hits += 1; });
  assert.equal(hits,1);
  assert.equal(player.health,2);
  assert.equal(bullet.active,false);
});

test('重複取得草莓會升至五向並在 Lv.3 強化傷害', () => {
  const ns = loadGameCore();
  const skills = new ns.systems.SkillSystem(() => 0);
  const player = new ns.entities.Player(240,560);
  const context = { player, enemies:[], enemyBullets:[], onDestroyed(){} };
  skills.collect(new ns.entities.PowerUp(0,0,'strawberry'),context);
  skills.collect(new ns.entities.PowerUp(0,0,'strawberry'),context);
  skills.collect(new ns.entities.PowerUp(0,0,'strawberry'),context);
  const bullets=[];
  new ns.systems.Weapon().update(0.2,player,bullets,skills);
  assert.equal(skills.level('spread'),3);
  assert.equal(bullets.length,5);
  assert.equal(bullets[2].damage,1.5);
});

test('Combo 每五次擊破提升倍率，受傷規則可中斷', () => {
  const ns = loadGameCore();
  const state = new ns.systems.GameState();
  for (let i=0;i<5;i+=1) state.registerKill(100);
  assert.equal(state.combo,5);
  assert.equal(state.multiplier,2);
  assert.equal(state.score,600);
  state.breakCombo();
  assert.equal(state.combo,0);
  assert.equal(state.multiplier,1);
});

test('結束遊戲會保存最高分與歷史最高 Combo', () => {
  const ns = loadGameCore();
  const state = new ns.systems.GameState();
  for (let i=0;i<7;i+=1) state.registerKill(100);
  state.end();
  const next = new ns.systems.GameState();
  assert.equal(next.highScore,state.score);
  assert.equal(next.highCombo,7);
});

test('手機拖曳使用相對位移，不會讓手指遮住或瞬移戰機', () => {
  const ns = loadGameCore();
  const anchor = { clientX: 100, clientY: 200, playerX: 240, playerY: 560 };
  const target = ns.systems.InputController.touchTarget(anchor, { clientX: 125, clientY: 175 }, { left: 0, top: 0, width: 240, height: 360 }, { width: 480, height: 720 });
  assert.deepEqual({ x: target.x, y: target.y }, { x: 290, y: 510 });
});

test('四種難度可選擇，無效選項不會改變目前模式', () => {
  const ns = loadGameCore();
  assert.equal(ns.difficulty.all().length, 4);
  assert.equal(ns.difficulty.select('hard'), true);
  assert.equal(ns.difficulty.current().name, '困難');
  assert.equal(ns.difficulty.select('impossible'), false);
  assert.equal(ns.difficulty.current().id, 'hard');
});

test('無雙模式的散射與連射技能不會倒數消失', () => {
  const ns = loadGameCore();
  ns.difficulty.select('musou');
  const skills = new ns.systems.SkillSystem(() => 0);
  const context = { player:new ns.entities.Player(240,560), enemies:[], enemyBullets:[], onDestroyed(){} };
  skills.collect(new ns.entities.PowerUp(0,0,'strawberry'), context);
  skills.collect(new ns.entities.PowerUp(0,0,'banana'), context);
  skills.update(999, []);
  assert.equal(skills.timers.spread, Infinity);
  assert.equal(skills.timers.rapid, Infinity);
  assert.match(skills.status(context.player), /∞/);
});

test('鳳梨依難度維持稀有權重，龍果不進一般掉落池', () => {
  const ns = loadGameCore();
  assert.equal(ns.difficulty.all().find((mode) => mode.id === 'casual').weights.pineapple, 0.10);
  assert.equal(ns.difficulty.all().find((mode) => mode.id === 'normal').weights.pineapple, 0.06);
  assert.equal(ns.difficulty.all().find((mode) => mode.id === 'hard').weights.pineapple, 0.04);
  assert.equal(ns.difficulty.all().find((mode) => mode.id === 'musou').weights.pineapple, 0.02);
  ns.difficulty.select('normal');
  const skills = new ns.systems.SkillSystem(() => 0.99);
  const powerUps = [];
  skills.spawn(powerUps, 100, 100);
  assert.equal(powerUps[0].type, 'pineapple');
  assert.notEqual(powerUps[0].type, 'dragonfruit');
});

test('高難度讓威脅更快升級且敵潮間隔更短', () => {
  const ns = loadGameCore();
  const normal = new ns.systems.Spawner(() => 0.5);
  const normalInterval = normal.currentInterval();
  ns.difficulty.select('musou');
  const musou = new ns.systems.Spawner(() => 0.5);
  assert.ok(musou.currentInterval() < normalInterval);
  musou.elapsed = 13;
  assert.equal(musou.threatLevel(), 3);
});

test('完成限時獵殺事件會掉落限定龍果', () => {
  const ns = loadGameCore();
  const challenge = new ns.systems.ChallengeSystem();
  const context = { player:new ns.entities.Player(240,560), powerUps:[], effects:{ announce(){} } };
  challenge.update(13.1, context);
  assert.equal(challenge.active.type, 'hunt');
  const target = challenge.active.target;
  for (let i=0; i<target; i+=1) challenge.onKill(context);
  assert.equal(context.powerUps.length, 1);
  assert.equal(context.powerUps[0].type, 'dragonfruit');
});

test('無傷事件受傷會失敗且不會發放龍果', () => {
  const ns = loadGameCore();
  const challenge = new ns.systems.ChallengeSystem();
  const context = { player:new ns.entities.Player(240,560), powerUps:[], effects:{ announce(){} } };
  challenge.sequence = 1;
  challenge.cooldown = 0;
  challenge.update(0.01, context);
  assert.equal(challenge.active.type, 'survive');
  challenge.onPlayerDamaged(context);
  assert.equal(challenge.active, null);
  assert.equal(context.powerUps.length, 0);
});

test('桌面指標位置可正確換算成 Canvas 座標', () => {
  const ns = loadGameCore();
  const point = ns.systems.InputController.canvasPoint({ clientX: 130, clientY: 210 }, { left: 10, top: 30, width: 240, height: 360 }, { width: 480, height: 720 });
  assert.deepEqual({ x: point.x, y: point.y }, { x: 240, y: 360 });
});

test('戰場背景建立遠近分層星流與環境光塵', () => {
  const ns = loadGameCore();
  const battlefield = new ns.systems.BattlefieldRenderer(() => 0.5);
  assert.equal(battlefield.stars.length, 82);
  assert.equal(battlefield.motes.length, 13);
  const firstY = battlefield.stars[0].y;
  battlefield.update(0.1);
  assert.ok(battlefield.stars[0].y > firstY);
});

test('擊破效果建立粒子、衝擊波與有限震動回饋', () => {
  const ns = loadGameCore();
  const effects = new ns.systems.Effects(() => 0.5);
  effects.burst(100, 120, '#ffffff', 1);
  assert.equal(effects.flashes.length, 1);
  assert.ok(effects.particles.length >= 20);
  assert.ok(effects.trauma > 0);
  effects.update(2);
  assert.equal(effects.flashes.length, 0);
  assert.equal(effects.particles.length, 0);
});

test('遠征包含 100 波且每五波固定為 Boss 戰', () => {
  const ns = loadGameCore();
  const stage = new ns.systems.StageDirector();
  assert.equal(stage.totalWaves, 100);
  [5,10,55,100].forEach((wave) => assert.equal(stage.isBossWave(wave), true));
  [1,4,6,99].forEach((wave) => assert.equal(stage.isBossWave(wave), false));
});

test('第一波清場後進入第二波並保證掉落鏡像核心', () => {
  const ns = loadGameCore();
  const stage = new ns.systems.StageDirector();
  const context = { player:new ns.entities.Player(240,560), enemies:[], powerUps:[], enemyBullets:[], effects:{announce(){}} };
  stage.timer = 0;
  stage.phase = 'clear';
  stage.update(0.01, context);
  assert.equal(stage.wave, 2);
  assert.equal(context.powerUps.length, 1);
  assert.equal(context.powerUps[0].type, 'mirror');
});

test('第五波會生成具有三階段攻擊的 Boss', () => {
  const ns = loadGameCore();
  const stage = new ns.systems.StageDirector();
  stage.wave = 5;
  const context = { player:new ns.entities.Player(240,560), enemies:[], powerUps:[], enemyBullets:[], effects:{announce(){}} };
  stage.update(0.01, context);
  assert.equal(context.enemies.length, 1);
  const boss = context.enemies[0];
  assert.equal(boss.type, 'boss');
  boss.y = 112;
  boss.health = boss.maxHealth * 0.3;
  boss.fireCooldown = 0;
  boss.update(0.016, { player:context.player, enemyBullets:context.enemyBullets, enemySpeed:1 });
  assert.equal(boss.phase, 3);
  assert.equal(context.enemyBullets.length, 14);
});

test('敵機突破底線會標記逃脫並扣除防線耐久', () => {
  const ns = loadGameCore();
  const enemy = new ns.entities.Enemy(240, ns.config.height + 80);
  enemy.update(0.016, { enemySpeed:1 });
  assert.equal(enemy.escaped, true);
  const stage = new ns.systems.StageDirector();
  const before = stage.integrity;
  assert.equal(stage.onEnemyEscaped(enemy, { effects:{ announce(){} } }), 1);
  assert.equal(stage.integrity, before - 1);
});

test('大型敵機突破扣兩點且防線歸零會使遠征失敗', () => {
  const ns = loadGameCore();
  ns.difficulty.select('hard');
  const stage = new ns.systems.StageDirector();
  stage.integrity = 2;
  const elite = new ns.entities.Enemy(240, 800, { type:'elite', health:10 });
  stage.onEnemyEscaped(elite, { effects:{ announce(){} } });
  assert.equal(stage.integrity, 0);
  assert.equal(stage.failed, true);
  assert.equal(stage.phase, 'failed');
});

test('波次依序套用狂戰、鐵壁、疾射與雙生符文', () => {
  const ns = loadGameCore();
  const stage = new ns.systems.StageDirector();
  const expected = ['frenzy','fortified','rapid'];
  [2,3,4].forEach((wave,index) => { stage.wave=wave; assert.equal(stage.affix().id, expected[index]); });
  stage.wave=6;
  assert.equal(stage.affix().id, 'twin');
  stage.wave=5;
  assert.equal(stage.affix().id, 'boss');
});

test('鐵壁詞綴提高敵機生命，雙生詞綴可生成編隊', () => {
  const ns = loadGameCore();
  const spawner = new ns.systems.Spawner(() => 0);
  spawner.setModifiers({ health:1.55, score:1.2, twinChance:1 });
  const enemies=[];
  spawner.timer=0;
  spawner.update(0.016,enemies);
  assert.equal(enemies.length,2);
  assert.equal(enemies[0].health,3);
  assert.notEqual(enemies[0].x,enemies[1].x);
});

test('Boss 第一階段彈幕會以玩家方向為中心瞄準', () => {
  const ns = loadGameCore();
  const boss = new ns.entities.Boss(5, ns.difficulty.current());
  boss.x=120;boss.y=112;boss.fireCooldown=0;
  const player=new ns.entities.Player(360,560);const bullets=[];
  boss.update(0.016,{player,enemyBullets:bullets,enemySpeed:1,enemyFireRate:1});
  assert.equal(bullets.length,6);
  assert.ok(bullets.reduce((sum,bullet) => sum+bullet.vx,0) > 0);
  assert.ok(bullets.every((bullet) => bullet.vy > 0));
});

test('鏡像僚機與星靈戰寵可同時自動射擊', () => {
  const ns = loadGameCore();
  const support = new ns.systems.SupportSystem();
  support.collect('mirror');
  support.collect('familiar');
  const player = new ns.entities.Player(240,560);
  const enemy = new ns.entities.Enemy(240,120);
  const bullets = [];
  support.update(0.1, player, [enemy], bullets);
  assert.equal(support.cloneLevel, 1);
  assert.equal(support.familiarLevel, 1);
  assert.equal(bullets.length, 2);
  assert.ok(bullets.some((bullet) => bullet.vy < 0));
  assert.match(support.status(), /分身 L1.*戰寵 L1/);
});
